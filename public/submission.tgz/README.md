# 🌌 GreenieVerse Kaggle Submission Archive

## Structure
- `main.py`: The entry point agent script with `def agent(observation, configuration=None)` as the last function.
- `metadata.json`: Competition submission meta specifications.
- `README.md`: Execution documentation.

## Running Locally / Kaggle Environment
```bash
python3 -c "import main; print(main.agent({'turn': 1, 'cash': 250, 'grid': [], 'market': {}, 'inventory': {}}))"
```
